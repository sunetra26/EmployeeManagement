package com.cts.Employee.service.impl;

import com.cts.Employee.exception.ResourceNotFoundException;

import java.util.List;
import java.util.Optional;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.cts.Employee.model.Employee;
import com.cts.Employee.repository.EmployeeRepository;
import com.cts.Employee.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeRepository employeeRepository;

	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	@Cacheable(value = "employee-cache", key = "#employeeId")
	public Optional<Employee> getByEmployeeId(Long employeeId) {
		Optional<Employee> employee = employeeRepository.findById(employeeId);
		return employee;
	}

	@Override
	public List<Employee> listAllEmployee() {
		return employeeRepository.findAll();
	}
	
	@Override
	public Employee updateEmployee(Employee employee, long id) {
		
		// we need to check whether employee with given id is exist in DB or not
		Employee existingEmployee = employeeRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Employee", "Id", id)); 
		
		existingEmployee.setFirstName(employee.getFirstName());
		existingEmployee.setLastName(employee.getLastName());
		existingEmployee.setAddress(employee.getAddress());
		existingEmployee.setEmail(employee.getEmail());
		existingEmployee.setJoiningDate(employee.getJoiningDate());
		existingEmployee.setNumber(employee.getNumber());
		existingEmployee.setEmploymentHistory(employee.getEmploymentHistory());
		existingEmployee.setProjectDetails(employee.getProjectDetails());
		existingEmployee.setSalary(employee.getSalary());
		// save existing employee to DB
		employeeRepository.save(existingEmployee);
		return existingEmployee;
	}

	@Override
	@CacheEvict(value = "employee-cache", key = "#employeeId")
	public void deleteByEmployeeId(Long employeeId) {
		Optional<Employee> employee = getByEmployeeId(employeeId);
		if (!employee.isEmpty()) {
			employeeRepository.delete(employee.get());
		}
	}
}
