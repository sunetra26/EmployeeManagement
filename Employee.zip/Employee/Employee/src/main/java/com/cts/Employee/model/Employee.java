package com.cts.Employee.model;

import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="employees")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "first_name", nullable = false)
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name="address")
	private String address;
	
	@Column(name = "personal_email")
	private String email;
	
	@Column(name="joining_date")
	private Date joiningDate;
	
	@Column(name="contact_number")
	private long number;
	
	@Column(name="employment_history")
	private String employmentHistory;
	
	@Column(name="project_details")
	private String projectDetails;
	
	@Column(name="salary")
	private long salary;
	
}


