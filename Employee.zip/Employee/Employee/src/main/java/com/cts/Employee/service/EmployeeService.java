package com.cts.Employee.service;

import java.util.List;
import java.util.Optional;

import com.cts.Employee.model.Employee;

public interface EmployeeService {
	
	Employee saveEmployee(Employee employee);

	Optional<Employee> getByEmployeeId(Long employeeId);

	List<Employee> listAllEmployee();
	
	Employee updateEmployee(Employee employee,long id);

	void deleteByEmployeeId(Long employeeId);

}
